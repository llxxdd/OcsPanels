<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-9"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
		<title>Panel Reseller</title>
		<!-- core CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
		
		<link href="<?= base_url('asset/css/sb-admin-2.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		<!--[if lt IE 9]>
		<script src="<?= base_url('asset/js/html5shiv.js');?>"></script>
		<script src="<?= base_url('asset/js/respond.min.js');?>"></script>
		<![endif]-->
		<link rel="shortcut icon" href="<?= base_url('images/ico/favicon.ico')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?= base_url('images/ico/apple-touch-icon-144-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?= base_url('images/ico/apple-touch-icon-114-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?= base_url('images/ico/apple-touch-icon-72-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" href="<?= base_url('images/ico/apple-touch-icon-57-precomposed.png')?>"/>
</head>	
  <table width="100%"><tbody><tr><td><div style="border-bottom: 1px solid #b4d900; margin-left: 4px; margin-right: 4px;"></div><div style="background-color: #ffffff; border-left: 2px solid #b4d900; border-right: 2px solid #b4d900; padding-top: 1px; margin-left: 2px; margin-right: 2px;"></div><div style="background-color: #e6facd; border-left: 1px solid #b4d900; border-right: 1px solid #b4d900; padding-top: 2px; margin-left: 1px; margin-right: 1px;"></div><div style="background: #e4f9ad repeat bottom; padding-left: 2px; border-left: 1px solid #b4d900; padding-right: 3px; border-right: 1px solid #b4d900;" align="left"><div align="center"><marquee direction="right"><style>b.van {text-shadow: 1px 1px 0 #ffcc00 , 2px 2px 0 #ff9900 , 2px 2px 0 #ff6600 , 2px 2px 0 #ff3300 , 2px 2px #ff0000 , 3px 3px 0 red }</style><big><font color="red" size="6"><b class="van">WELCOME</b></font></big></marquee><br><marquee direction="left"><style> b.mrtam{font-size:72px;color:#555500;text-align:center;text-shadow:1px 1px 0 #999900,2px 2px 0 #AAAA00,3px 3px 0 #BBBB00,4px 4px 0 #CCCC00,5px 5px 0 #DDDD00,6px 6px 0 #999900,7px 8px 0 #555500;}</style><big><font size="7"><b class="mrtam">Web Reseller</b></font></big></marquee></div></div><div style="background-color: #e6facd; border-left: 1px solid #b4d900; border-right: 1px solid #b4d900; padding-top: 2px; margin-left: 1px; margin-right: 1px;"></div><div style="background-color: #ffffff; border-left: 2px solid #b4d900; border-right: 2px solid #b4d900; padding-top: 1px; margin-left: 2px; margin-right: 2px;"></div><div style="border-bottom: 1px solid #b4d900; margin-left: 4px; margin-right: 4px;"></div></td></tr></tbody></table>
<div id="wrapper"> 
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 20%">
        <div class="navbar-header">
            <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">  
          <b style="color: red" class="glyphicon glyphicon-align-justify"><strong>  MENU</strong></b>        
          </button>
      </div>
          <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="row">
                            <div class="col-xs-5">
                                <span class="fa-stack fa-3x">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-user fa-stack-1x fa-inverse"></i>
                                </span>
                            </div>
                            <?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
                            <div class="col-xs-7">
                                <h4><b><?= $_SESSION['username'] ?></b></h4>
                                <h4 class="text-muted"><?php if ($_SESSION['is_admin']) { echo "Administrator"; } else {echo "Seller"; } ?></h4>
                            </div>
                        </div>
                    </li>
						<?php if ($_SESSION['is_admin']): ?>
                  
                            <li>
                                <a href="<?= base_url('panel/administrator/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-th-list fa-fw"></i> Server</a>
                            </li>
                            <li>
                                <a href="<?= base_url('admin/notify') ?>"><span class="glyphicon glyphicon-envelope"></span> Inbox <?php if (isset($msg)): ?>
									<span class="badge"><?= count($msg) ?></span>
                                
                                <?php endif; ?>
                                </a>
                            </li>
						<li><a href="<?= base_url('panel/'.$_SESSION['username'].'/setting')?>"><i class="fa fa-key"></i> Change Password</a></li>
							<li><a href="<?= base_url('admin/asset')?>"><i class="fa fa-phone"></i> Deposit Via Topup</a></li>
							<li><a href="<?= base_url('admin/asset_req')?>"><i class="fa fa-credit-card"></i> Deposit Via Banking</a></li>
                        <?php else: ?>
                         <li>
                              <a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-shopping-cart fa-fw"></i> Create Account Now</a>
                        </li>
                        <li>
                              <a href="<?= base_url('panel/reseller/cek_account/'.$_SESSION['username']) ?>"><i class="fa fa-users"></i> Check User List</a>
                        </li>
                        <li>
							<a href="<?= base_url('panel/'.$_SESSION['username'].'/setting')?>"><i class="fa fa-gear fa-fw"></i> Setting</a>
                        </li>
                        
                        <?php endif; ?>
					  <li>
                        <a href="<?= base_url('panel/'.$_SESSION['username'].'/logout')?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</div>
