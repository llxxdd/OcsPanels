<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
	 <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"> Deposit Via Topup</h1>
            <div class="well"> Balance $: <B><?php if (isset($user->saldo)) {echo $user->saldo; }?></B></div>
        </div>
    </div>
    <div class="row">
		  <div class="col-sm-6">
			   <p class="text-muted">Notice: if you have paid, please click the confirmation then your balance will increase automatically after the admin check.</p>
			   <p class="text-info">Please send credit to one of the following no: </p>
			   <?php foreach ($this->user_model->view_asset() as $row): ?>
					<?php if (!empty($row['nohp'])): ?>
					<p class="text-default" align="center"> <?= $row['pemilik']?><br> <?= $row['nohp']?> <br> <?= $row['provider']?> </p>
					<?php endif; ?>	
			   <?php endforeach; ?>
		  </div>
           <div class="col-sm-6">
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?php if (isset($message)) : ?>
					<div class="col-md-12">
						<div class="alert alert-success" role="alert"><?= $message ?></div>
					</div>
					<?php endif;?>
			   <?= form_open() ?>
					<div class="form-group">
						<label for="sender"> User Name</label>
						<input type="text" name="sender" class="form-control" id="sender" placeholder="Enter your reseller username "/>
						<small class="text-muted">For proof has paid</small>
					</div>
					<div class="form-group">
						<label for="hp">Sent To</label>
						<select name="hp" id="hp" class="form-control">
							<?php foreach ($this->user_model->view_asset() as $row): ?>
							<?php if (!empty($row['nohp'])): ?>
							<option value="<?= $row['nohp']?>"><?= $row['nohp'].' ('.$row['provider'].')'?></option>
							<?php endif;?>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<label for="hp">Amount of deposit</label>
						<input type="number" name="jumlah" class="form-control" id="jumlah" value="5"/>
						<small class="text-muted">Minimum deposit amount is 5$</small>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary form-control" value="Confirm"/>
					</div>
			 
            </div>
    </div>

