<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section id="#login">
    <div class="container">
        <div class="row ver-parent">
            <div class="col-md-4 col-md-offset-4 ver-center">
                <?php if (validation_errors()) : ?>
                    <div class="alert alert-danger"><?= validation_errors() ?></div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
				<?php endif; ?>
               <center>
              <img src="http://i.imgur.com/fDbH6tr.png" /><br>      
              </center>  <br>   
                   <div class="panel panel-default">     
                    <div class="panel-heading">
                     <font > <marquee direction="left" scrollamount="4" style="color: #FF0000; rows: 5
                        background:#A9F5F2; font-size: 25px"> PANEL RESELLER SSH SSL VPN LOGIN</marquee></font>
                      </div> 
                    <div class="panel-body">
                        <?= form_open() ?>
                            <fieldset>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                                        <input class="form-control" placeholder="Username" name="username" type="text" autofocus required>
                                    </div>
                                 </div> 
                               
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                                        <input class="form-control" placeholder="Password" name="password" type="password" required>
                                    </div>
                                 </div>
                                <input type="submit" class="btn btn-lg btn-success btn-block" value="Login">
                            </fieldset>
                        </div>
                </div>
                <p>  &nbsp; Click here to create account: <a href="<?= base_url('panel/register') ?>"> Register Reseller</a></p>
            </div>
            </div>
        </div>
</section>
